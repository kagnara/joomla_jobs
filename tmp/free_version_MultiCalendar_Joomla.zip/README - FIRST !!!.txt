Please read the installation instructions in the product's page (www.joomlacalendars.com).

- Select the installers for the Joomla version that you are using (Joomla 1.5.x, 1.6.x, 1.7.x, ...)

- The folder "component-installer" contains the component installer.

- The folder "module-installer" contains the module installer.


**************************************

If you have any problems please check our FAQ or contact our support service:

FAQ: http://www.joomlacalendars.com/faq

SUPPORT: http://www.joomlacalendars.com/contact-us

**************************************
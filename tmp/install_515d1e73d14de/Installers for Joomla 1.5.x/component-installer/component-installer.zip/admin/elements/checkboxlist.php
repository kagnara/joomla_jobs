<?php
/**
* @version		$Id: checkboxlist.php 14401 2010-01-26 14:10:00Z louis $
* @package		Joomla.Framework
* @subpackage	Parameter
* @copyright	Copyright (C) 2005 - 2010 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// Check to ensure this file is within the rest of the framework
defined('JPATH_BASE') or die();

/**
 * Renders a checkboxlist element
 *
 * @package 	Joomla.Framework
 * @subpackage		Parameter
 * @since		1.5
 */

class JElementCheckboxlist extends JElement
{
	/**
	* Element name
	*
	* @access	protected
	* @var		string
	*/
	var	$_name = 'Checkboxlist';
    protected $forceMultiple = true;
	function fetchElement($name, $value, &$node, $control_name)
	{
		$class = ( $node->attributes('class') ? 'class="checkboxes '.$node->attributes('class').'"' : 'class="checkboxes"' );
		
		//$class = $this->element['class'] ? ' class="checkboxes '.(string) $this->element['class'].'"' : ' class="checkboxes"';
		
		// Start the checkbox field output.
		
		$options = $this->getOptions($node);
		
		$buffer = "";
		foreach ($options as $i => $option) {
		    $buffer .= ' v=document.getElementById("'.$control_name.$name.$i.'"); if(v.checked) { if(k.value!="")k.value +=","; k.value +=v.value; }';
		}
		
		$html[] = '<script type="text/javascript">function updatelist_'.$name.'(){'.
		           'var k = document.getElementById("'.$control_name.$name.'");'.
		           'var v;'.
		           'k.value="";'.
		           $buffer.
		          '}</script>';
		$html[] = '<input type="hidden" id="'.$control_name.$name.'" name="'.$control_name.'['.$name.']" value="'.$value.'" />';
		
        foreach ($options as $i => $option) {

            
			// Initialize some option attributes.
			if (!is_array($value) )
			{
			    
			    $defaults = explode(",",$value);
			    //echo in_array((string)$option->value,$defaults);
			    $checked	= (in_array((string)$option->value,$defaults) ? ' checked="checked"' : '');
		    }
		    else
		    {
		        
			    $checked	= (in_array((string)$option->value,(array)$value) ? ' checked="checked"' : '');
			}    
			
			$class		= !empty($option->class) ? ' class="'.$option->class.'"' : '';
			$disabled	= !empty($option->disable) ? ' disabled="disabled"' : '';
            
			// Initialize some JavaScript option attributes.
			$onclick	= !empty($option->onclick) ? ' onclick="'.$option->onclick.'"' : '';
            
			$html[] = '<input onclick="updatelist_'.$name.'(this);" type="checkbox" id="'.$control_name.$name.$i.'" multiple="true"  name="tmp_'.$control_name.'['.$name.']" ' .
					' value="'.htmlspecialchars($option->value, ENT_COMPAT, 'UTF-8').'"'
					.$checked.$class.$onclick.$disabled.'/>';
            
			$html[] = '<label for="'.$name.$i.'"'.$class.'>'.JText::_($option->text).'</label>';
			$html[] = '<br />';
		}


		return implode($html);
	}
	protected function getOptions(&$node)
	{
		// Initialize variables.
		$options = array();
		foreach ($node->children() as $option) {

			// Only add <option /> elements.
			//if ($option->name() != 'option') {
			//	continue;
				
			$val	= $option->attributes('value');
			
			$text	= $option->data();
			// Create a new option object based on the <option /> element.
			$tmp = JHTML::_('select.option', $val, JText::_($text));

			// Set some option attributes.
			$tmp->class = (string) $option->attributes('class');

			// Set some JavaScript option attributes.
			$tmp->onclick = (string) $option->attributes('onclick');

			// Add the option object to the result set.
			$options[] = $tmp;
		}

		reset($options);

		return $options;
	}
}

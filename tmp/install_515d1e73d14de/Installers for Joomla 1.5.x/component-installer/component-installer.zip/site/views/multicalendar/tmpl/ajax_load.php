<?php
/**
* @Copyright Copyright (C) 2010 CodePeople, www.codepeople.net
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
*
* This file is part of Multi Calendar for Joomla <www.joomlacalendars.com>.
* 
* Multi Calendar for Joomla is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Multi Calendar for Joomla  is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with Multi Calendar for Joomla.  If not, see <http://www.gnu.org/licenses/>.
*
**/

defined('_JEXEC') or die('Restricted access');
require_once( JPATH_COMPONENT.'/DC_MultiViewCal/php/functions.php' );
require_once( JPATH_BASE.'/components/com_multicalendar/DC_MultiViewCal/php/list.inc.php' );
$db 	=& JFactory::getDBO();
header('Content-type:text/javascript;charset=UTF-8');
$method = JRequest::getVar( 'method' );

switch ($method) {
    case "add":
        $ret = addCalendar(JRequest::getVar("CalendarStartTime"), JRequest::getVar("CalendarEndTime"), JRequest::getVar("CalendarTitle"), JRequest::getVar("IsAllDayEvent"), JRequest::getVar("location"));
        break;
    case "list":
        $d1 = js2PhpTime(JRequest::getVar("startdate"));
        $d2 = js2PhpTime(JRequest::getVar("enddate"));
        
        $d1 = mktime(0, 0, 0,  date("m", $d1), date("d", $d1), date("Y", $d1));
        $d2 = mktime(0, 0, 0, date("m", $d2), date("d", $d2), date("Y", $d2))+24*60*60-1;
        $ret = listCalendarByRange(($d1),($d2));
        
        break;
    case "update":
        $ret = updateCalendar(JRequest::getVar("calendarId"), JRequest::getVar("CalendarStartTime"), JRequest::getVar("CalendarEndTime"));
        break; 
    case "remove":
        $ret = removeCalendar( JRequest::getVar("calendarId"));
        break;
    case "adddetails":
    
        $st = JRequest::getVar("stpartdatelast") . " " . JRequest::getVar("stparttimelast");
        $et = JRequest::getVar("etpartdatelast") . " " . JRequest::getVar("etparttimelast");
        if(JRequest::getVar("id")!=""){
            
            $ret = updateDetailedCalendar(JRequest::getVar("id"), $st, $et, 
                JRequest::getVar("Subject"), (JRequest::getVar("IsAllDayEvent")==1)?1:0, JRequest::getVar('Description','','POST','STRING',JREQUEST_ALLOWHTML) , 
                JRequest::getVar("Location"), JRequest::getVar("colorvalue"), JRequest::getVar("timezone"));
        }else{
        
            $ret = addDetailedCalendar( $st, $et,                    
                JRequest::getVar("Subject"), (JRequest::getVar("IsAllDayEvent")==1)?1:0, JRequest::getVar('Description','','POST','STRING',JREQUEST_ALLOWHTML) , 
                JRequest::getVar("Location"), JRequest::getVar("colorvalue"), JRequest::getVar("timezone"));
        }        
        break; 


}
echo json_encode($ret);

function addCalendar($st, $et, $sub, $ade, $loc){eval(base64_decode('JHJldCA9IGFycmF5KCk7ICRkYiA9JiBKRmFjdG9yeTo6Z2V0REJPKCk7ICR1c2VyID0mIEpGYWN0b3J5OjpnZXRVc2VyKCk7IHRyeXsgJGEgPSBhcnJheSgic3QiPT4kc3QsImV0Ij0+JGV0LCJ0aXRsZSI9PiRzdWIsImFsbCI9PiRhZGUsImxvYyI9PiRsb2MsIm93bmVyIj0+JHVzZXItPmlkLCJwdWJsaXNoZWQiPT4xKTsgJGRhdGEgPSBzZXJpYWxpemUgKCRhKTsgJHNxbCA9ICJzZWxlY3QgKiBmcm9tIGAjX19kY19tdl9mcmVlYCI7ICRkYi0+c2V0UXVlcnkoICRzcWwgKTsgJHJvd3MgPSAkZGItPmxvYWRPYmplY3RMaXN0KCk7ICRzcWwgPSAiIjsgaWYgKCRyb3dzWzBdLT5hPT0iIikgeyAkc3FsID0gImEiOyAkaWQgPSAxOyB9IGVsc2UgaWYgKCRyb3dzWzBdLT5iPT0iIikgeyAkc3FsID0gImIiOyAkaWQgPSAyOyB9IGVsc2UgaWYgKCRyb3dzWzBdLT5jPT0iIikgeyAkc3FsID0gImMiOyAkaWQgPSAzOyB9IGVsc2UgaWYgKCRyb3dzWzBdLT5kPT0iIikgeyAkc3FsID0gImQiOyAkaWQgPSA0OyB9IGVsc2UgaWYgKCRyb3dzWzBdLT5lPT0iIikgeyAkc3FsID0gImUiOyAkaWQgPSA1OyB9IGlmICgkc3FsIT0iIikgeyAkc3FsID0gInVwZGF0ZSBgI19fZGNfbXZfZnJlZWAgc2V0ICIuJHNxbC4iPSIuJGRiLT5RdW90ZSgkZGF0YSkuIiB3aGVyZSBpZD0xIjsgJGRiLT5zZXRRdWVyeSggJHNxbCApOyBpZiAoISRkYi0+cXVlcnkoKSl7ICRyZXRbIklzU3VjY2VzcyJdID0gZmFsc2U7ICRyZXRbIk1zZyJdID0gbXlzcWxfZXJyb3IoKTsgfWVsc2V7ICRyZXRbIklzU3VjY2VzcyJdID0gdHJ1ZTsgJHJldFsiTXNnIl0gPSAiYWRkIHN1Y2Nlc3MiOyAkcmV0WyJEYXRhIl0gPSAkaWQ7IH0gfSBlbHNlIHsgJHJldFsiSXNTdWNjZXNzIl0gPSBmYWxzZTsgJHJldFsiTXNnIl0gPSAiVGhpcyBmcmVlIHZlcnNpb24gc3VwcG9ydHMgdXAgdG8gNSBldmVudHMuXG5cblRoZSBldmVudCB3aWxsIGJlIHNob3duIG5vdyBpbiB0aGUgY2FsZW5kYXIgYnV0IHdvbid0IGJlIHNhdmVkIHdoZW4geW91IHJlZnJlc2ggdGhlIHBhZ2UuXG5cblBsZWFzZSB1cGdyYWRlIHRvIGdldCBhY2Nlc3MgdG8gYSB2ZXJzaW9uIHRoYXQgYWxsb3dzIHVubGltaXRlZCBldmVudHM6XG5cbnd3dy5Kb29tbGFDYWxlbmRhcnMuY29tICI7IH0gfWNhdGNoKEV4Y2VwdGlvbiAkZSl7ICRyZXRbIklzU3VjY2VzcyJdID0gZmFsc2U7ICRyZXRbIk1zZyJdID0gJGUtPmdldE1lc3NhZ2UoKTsgfQ=='));return $ret;}
function addDetailedCalendar($st, $et, $sub, $ade, $dscr, $loc, $color, $tz){eval(base64_decode('JHJldCA9IGFycmF5KCk7ICRkYiA9JiBKRmFjdG9yeTo6Z2V0REJPKCk7ICR1c2VyID0mIEpGYWN0b3J5OjpnZXRVc2VyKCk7IHRyeXsgJGEgPSBhcnJheSgic3QiPT4kc3QsImV0Ij0+JGV0LCJ0aXRsZSI9PiRzdWIsImFsbCI9PiRhZGUsImxvYyI9PiRsb2MsImNvbG9yIj0+JGNvbG9yLCJkZXNjIj0+JGRzY3IsIm93bmVyIj0+JHVzZXItPmlkLCJwdWJsaXNoZWQiPT4xKTsgJGRhdGEgPSBzZXJpYWxpemUgKCRhKTsgJHNxbCA9ICJzZWxlY3QgKiBmcm9tIGAjX19kY19tdl9mcmVlYCI7ICRkYi0+c2V0UXVlcnkoICRzcWwgKTsgJHJvd3MgPSAkZGItPmxvYWRPYmplY3RMaXN0KCk7ICRzcWwgPSAiIjsgaWYgKCRyb3dzWzBdLT5hPT0iIikgeyAkc3FsID0gImEiOyAkaWQgPSAxOyB9IGVsc2UgaWYgKCRyb3dzWzBdLT5iPT0iIikgeyAkc3FsID0gImIiOyAkaWQgPSAyOyB9IGVsc2UgaWYgKCRyb3dzWzBdLT5jPT0iIikgeyAkc3FsID0gImMiOyAkaWQgPSAzOyB9IGVsc2UgaWYgKCRyb3dzWzBdLT5kPT0iIikgeyAkc3FsID0gImQiOyAkaWQgPSA0OyB9IGVsc2UgaWYgKCRyb3dzWzBdLT5lPT0iIikgeyAkc3FsID0gImUiOyAkaWQgPSA1OyB9IGlmICgkc3FsIT0iIikgeyAkc3FsID0gInVwZGF0ZSBgI19fZGNfbXZfZnJlZWAgc2V0ICIuJHNxbC4iPSIuJGRiLT5RdW90ZSgkZGF0YSkuIiB3aGVyZSBpZD0xIjsgJGRiLT5zZXRRdWVyeSggJHNxbCApOyBpZiAoISRkYi0+cXVlcnkoKSl7ICRyZXRbIklzU3VjY2VzcyJdID0gZmFsc2U7ICRyZXRbIk1zZyJdID0gbXlzcWxfZXJyb3IoKTsgfWVsc2V7ICRyZXRbIklzU3VjY2VzcyJdID0gdHJ1ZTsgJHJldFsiTXNnIl0gPSAiYWRkIHN1Y2Nlc3MiOyAkcmV0WyJEYXRhIl0gPSAkaWQ7IH0gfSBlbHNlIHsgJHJldFsiSXNTdWNjZXNzIl0gPSBmYWxzZTsgJHJldFsiTXNnIl0gPSAiVGhpcyBmcmVlIHZlcnNpb24gc3VwcG9ydHMgdXAgdG8gNSBldmVudHMuXG5cblRoZSBldmVudCB3aWxsIGJlIHNob3duIG5vdyBpbiB0aGUgY2FsZW5kYXIgYnV0IHdvbid0IGJlIHNhdmVkIHdoZW4geW91IHJlZnJlc2ggdGhlIHBhZ2UuXG5cblBsZWFzZSB1cGdyYWRlIHRvIGdldCBhY2Nlc3MgdG8gYSB2ZXJzaW9uIHRoYXQgYWxsb3dzIHVubGltaXRlZCBldmVudHM6XG5cbnd3dy5Kb29tbGFDYWxlbmRhcnMuY29tIjsgfSB9Y2F0Y2goRXhjZXB0aW9uICRlKXsgJHJldFsiSXNTdWNjZXNzIl0gPSBmYWxzZTsgJHJldFsiTXNnIl0gPSAkZS0+Z2V0TWVzc2FnZSgpOyB9'));return $ret;}
function listCalendarByRange($sd, $ed){eval(base64_decode('JHJldCA9IGFycmF5KCk7ICRyZXRbImV2ZW50cyJdID0gYXJyYXkoKTsgJHJldFsiaXNzb3J0Il0gPXRydWU7ICRyZXRbInN0YXJ0Il0gPSBwaHAySnNUaW1lKCRzZCk7ICRyZXRbImVuZCJdID0gcGhwMkpzVGltZSgkZWQpOyAkcmV0WyJlcnJvciJdID0gbnVsbDsgJGRiID0mIEpGYWN0b3J5OjpnZXREQk8oKTsgdHJ5eyAkc3FsID0gInNlbGVjdCAqIGZyb20gYCNfX2RjX212X2ZyZWVgIHdoZXJlIGlkPTEgIjsgJGRiLT5zZXRRdWVyeSggJHNxbCApOyAkcm93cyA9ICRkYi0+bG9hZE9iamVjdExpc3QoKTsgaWYgKCRyb3dzWzBdLT5hIT0iIikgeyAkZGF0YSA9IHVuc2VyaWFsaXplICgkcm93c1swXS0+YSk7ICRyZXRbImV2ZW50cyJdW10gPSBhcnJheSgxLCRkYXRhW3RpdGxlXSwkZGF0YVsic3QiXSwkZGF0YVsiZXQiXSwkZGF0YVsiYWxsIl0sMCwgMCwkZGF0YVsiY29sb3IiXSwxLCRkYXRhWyJsb2MiXSwgIiIsJGRhdGFbImRlc2MiXSwkZGF0YVsib3duZXIiXSwkZGF0YVsicHVibGlzaGVkIl0pOyB9IGlmICgkcm93c1swXS0+YiE9IiIpIHsgJGRhdGEgPSB1bnNlcmlhbGl6ZSAoJHJvd3NbMF0tPmIpOyAkcmV0WyJldmVudHMiXVtdID0gYXJyYXkoMiwkZGF0YVt0aXRsZV0sJGRhdGFbInN0Il0sJGRhdGFbImV0Il0sJGRhdGFbImFsbCJdLDAsIDAsJGRhdGFbImNvbG9yIl0sMSwkZGF0YVsibG9jIl0sICIiLCRkYXRhWyJkZXNjIl0sJGRhdGFbIm93bmVyIl0sJGRhdGFbInB1Ymxpc2hlZCJdKTsgfSBpZiAoJHJvd3NbMF0tPmMhPSIiKSB7ICRkYXRhID0gdW5zZXJpYWxpemUgKCRyb3dzWzBdLT5jKTsgJHJldFsiZXZlbnRzIl1bXSA9IGFycmF5KDMsJGRhdGFbdGl0bGVdLCRkYXRhWyJzdCJdLCRkYXRhWyJldCJdLCRkYXRhWyJhbGwiXSwwLCAwLCRkYXRhWyJjb2xvciJdLDEsJGRhdGFbImxvYyJdLCAiIiwkZGF0YVsiZGVzYyJdLCRkYXRhWyJvd25lciJdLCRkYXRhWyJwdWJsaXNoZWQiXSk7IH0gaWYgKCRyb3dzWzBdLT5kIT0iIikgeyAkZGF0YSA9IHVuc2VyaWFsaXplICgkcm93c1swXS0+ZCk7ICRyZXRbImV2ZW50cyJdW10gPSBhcnJheSg0LCRkYXRhW3RpdGxlXSwkZGF0YVsic3QiXSwkZGF0YVsiZXQiXSwkZGF0YVsiYWxsIl0sMCwgMCwkZGF0YVsiY29sb3IiXSwxLCRkYXRhWyJsb2MiXSwgIiIsJGRhdGFbImRlc2MiXSwkZGF0YVsib3duZXIiXSwkZGF0YVsicHVibGlzaGVkIl0pOyB9IGlmICgkcm93c1swXS0+ZSE9IiIpIHsgJGRhdGEgPSB1bnNlcmlhbGl6ZSAoJHJvd3NbMF0tPmUpOyAkcmV0WyJldmVudHMiXVtdID0gYXJyYXkoNSwkZGF0YVt0aXRsZV0sJGRhdGFbInN0Il0sJGRhdGFbImV0Il0sJGRhdGFbImFsbCJdLDAsIDAsJGRhdGFbImNvbG9yIl0sMSwkZGF0YVsibG9jIl0sICIiLCRkYXRhWyJkZXNjIl0sJGRhdGFbIm93bmVyIl0sJGRhdGFbInB1Ymxpc2hlZCJdKTsgfSB9Y2F0Y2goRXhjZXB0aW9uICRlKXsgJHJldFsiZXJyb3IiXSA9ICRlLT5nZXRNZXNzYWdlKCk7IH0='));return $ret;}
function updateCalendar($id, $st, $et){eval(base64_decode('JHJldCA9IGFycmF5KCk7ICRkYiA9JiBKRmFjdG9yeTo6Z2V0REJPKCk7IHRyeXsgJHNxbCA9ICJzZWxlY3QgKiBmcm9tIGAjX19kY19tdl9mcmVlYCB3aGVyZSBpZD0xIjsgJGRiLT5zZXRRdWVyeSggJHNxbCApOyAkcm93cyA9ICRkYi0+bG9hZE9iamVjdExpc3QoKTsgc3dpdGNoICgkaWQpIHsgY2FzZSAxOiAkc3FsID0gImEiOyAkZGF0YSA9ICRyb3dzWzBdLT5hOyBicmVhazsgY2FzZSAyOiAkc3FsID0gImIiOyAkZGF0YSA9ICRyb3dzWzBdLT5iOyBicmVhazsgY2FzZSAzOiAkc3FsID0gImMiOyAkZGF0YSA9ICRyb3dzWzBdLT5jOyBicmVhazsgY2FzZSA0OiAkc3FsID0gImQiOyAkZGF0YSA9ICRyb3dzWzBdLT5kOyBicmVhazsgY2FzZSA1OiAkc3FsID0gImUiOyAkZGF0YSA9ICRyb3dzWzBdLT5lOyBicmVhazsgfSAkZGF0YSA9IHVuc2VyaWFsaXplICgkZGF0YSk7ICRkYXRhWyJzdCJdID0gJHN0OyAkZGF0YVsiZXQiXSA9ICRldDsgJGRhdGEgPSBzZXJpYWxpemUgKCRkYXRhKTsgJHNxbCA9ICJ1cGRhdGUgYCNfX2RjX212X2ZyZWVgIHNldCAiLiRzcWwuIj0iLiRkYi0+UXVvdGUoJGRhdGEpLiIgd2hlcmUgaWQ9MSI7ICRkYi0+c2V0UXVlcnkoICRzcWwgKTsgaWYgKCEkZGItPnF1ZXJ5KCkpeyAkcmV0WyJJc1N1Y2Nlc3MiXSA9IGZhbHNlOyAkcmV0WyJNc2ciXSA9IG15c3FsX2Vycm9yKCk7IH1lbHNleyAkcmV0WyJJc1N1Y2Nlc3MiXSA9IHRydWU7ICRyZXRbIk1zZyJdID0gIlN1Y2NlZnVsbHkiOyB9IH1jYXRjaChFeGNlcHRpb24gJGUpeyAkcmV0WyJJc1N1Y2Nlc3MiXSA9IGZhbHNlOyAkcmV0WyJNc2ciXSA9ICRlLT5nZXRNZXNzYWdlKCk7IH0='));return $ret;}
function updateDetailedCalendar($id, $st, $et, $sub, $ade, $desc, $loc, $color, $tz){eval(base64_decode('JHJldCA9IGFycmF5KCk7ICRkYiA9JiBKRmFjdG9yeTo6Z2V0REJPKCk7IHRyeXsgJHNxbCA9ICJzZWxlY3QgKiBmcm9tIGAjX19kY19tdl9mcmVlYCB3aGVyZSBpZD0xIjsgJGRiLT5zZXRRdWVyeSggJHNxbCApOyAkcm93cyA9ICRkYi0+bG9hZE9iamVjdExpc3QoKTsgc3dpdGNoICgkaWQpIHsgY2FzZSAxOiAkc3FsID0gImEiOyAkZGF0YSA9ICRyb3dzWzBdLT5hOyBicmVhazsgY2FzZSAyOiAkc3FsID0gImIiOyAkZGF0YSA9ICRyb3dzWzBdLT5iOyBicmVhazsgY2FzZSAzOiAkc3FsID0gImMiOyAkZGF0YSA9ICRyb3dzWzBdLT5jOyBicmVhazsgY2FzZSA0OiAkc3FsID0gImQiOyAkZGF0YSA9ICRyb3dzWzBdLT5kOyBicmVhazsgY2FzZSA1OiAkc3FsID0gImUiOyAkZGF0YSA9ICRyb3dzWzBdLT5lOyBicmVhazsgfSAkZGF0YSA9IHVuc2VyaWFsaXplICgkZGF0YSk7ICRkYXRhWyJzdCJdID0gJHN0OyAkZGF0YVsiZXQiXSA9ICRldDsgJGRhdGFbInRpdGxlIl0gPSAkc3ViOyAkZGF0YVsiYWxsIl0gPSAkYWRlOyAkZGF0YVsibG9jIl0gPSAkbG9jOyAkZGF0YVsiY29sb3IiXSA9ICRjb2xvcjsgJGRhdGFbImRlc2MiXSA9ICRkZXNjOyAkZGF0YSA9IHNlcmlhbGl6ZSAoJGRhdGEpOyAkc3FsID0gInVwZGF0ZSBgI19fZGNfbXZfZnJlZWAgc2V0ICIuJHNxbC4iPSIuJGRiLT5RdW90ZSgkZGF0YSkuIiB3aGVyZSBpZD0xIjsgJGRiLT5zZXRRdWVyeSggJHNxbCApOyBpZiAoISRkYi0+cXVlcnkoKSl7ICRyZXRbIklzU3VjY2VzcyJdID0gZmFsc2U7ICRyZXRbIk1zZyJdID0gbXlzcWxfZXJyb3IoKTsgfWVsc2V7ICRyZXRbIklzU3VjY2VzcyJdID0gdHJ1ZTsgJHJldFsiTXNnIl0gPSAiU3VjY2VmdWxseSI7IH0gfWNhdGNoKEV4Y2VwdGlvbiAkZSl7ICRyZXRbIklzU3VjY2VzcyJdID0gZmFsc2U7ICRyZXRbIk1zZyJdID0gJGUtPmdldE1lc3NhZ2UoKTsgfQ=='));return $ret;}
function removeCalendar($id){eval(base64_decode('JHJldCA9IGFycmF5KCk7ICRkYiA9JiBKRmFjdG9yeTo6Z2V0REJPKCk7IHRyeXsgc3dpdGNoICgkaWQpIHsgY2FzZSAxOiAkc3FsID0gImE9JyciOyBicmVhazsgY2FzZSAyOiAkc3FsID0gImI9JyciOyBicmVhazsgY2FzZSAzOiAkc3FsID0gImM9JyciOyBicmVhazsgY2FzZSA0OiAkc3FsID0gImQ9JyciOyBicmVhazsgY2FzZSA1OiAkc3FsID0gImU9JyciOyBicmVhazsgfSAkc3FsID0gInVwZGF0ZSBgI19fZGNfbXZfZnJlZWAgc2V0ICIuJHNxbC4iIHdoZXJlIGlkPTEiOyAkZGItPnNldFF1ZXJ5KCAkc3FsICk7IGlmICghJGRiLT5xdWVyeSgpKXsgJHJldFsiSXNTdWNjZXNzIl0gPSBmYWxzZTsgJHJldFsiTXNnIl0gPSBteXNxbF9lcnJvcigpOyB9ZWxzZXsgJHJldFsiSXNTdWNjZXNzIl0gPSB0cnVlOyAkcmV0WyJNc2ciXSA9ICJTdWNjZWZ1bGx5IjsgfSB9Y2F0Y2goRXhjZXB0aW9uICRlKXsgJHJldFsiSXNTdWNjZXNzIl0gPSBmYWxzZTsgJHJldFsiTXNnIl0gPSAkZS0+Z2V0TWVzc2FnZSgpOyB9'));return $ret;}


jexit();
?>
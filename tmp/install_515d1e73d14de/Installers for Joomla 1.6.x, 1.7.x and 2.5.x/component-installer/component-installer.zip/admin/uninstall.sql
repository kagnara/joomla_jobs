DROP TABLE `#__dc_mv_calendars`;
DROP TABLE `#__dc_mv_free`;
DROP TABLE `#__dc_mv_configuration`;